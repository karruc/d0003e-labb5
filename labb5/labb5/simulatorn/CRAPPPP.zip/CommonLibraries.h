/*
 * CommonLibraries.h
 *
 * Created: 2022-05-18 20:57:59
 *  Author: 
 */ 


#ifndef COMMONLIBRARIES_H_
#define COMMONLIBRARIES_H_

#include <fcntl.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <unistd.h>
#include <semaphore.h>
#include <pthread.h>
#include <termios.h>


#endif /* COMMONLIBRARIES_H_ */